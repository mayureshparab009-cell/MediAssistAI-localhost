import React, { useState, useEffect } from 'react'
import { LayoutDashboard, Pill, Activity, Bot, FileText, Heart, ShieldAlert, HeartPulse } from 'lucide-react'
import Dashboard from './components/Dashboard'
import MedicationManager from './components/MedicationManager'
import SymptomTracker from './components/SymptomTracker'
import AIChatbot from './components/AIChatbot'
import ReportGenerator from './components/ReportGenerator'
import VitalsTracker from './components/VitalsTracker'

function App() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [dbStatus, setDbStatus] = useState('connecting')

  useEffect(() => {
    // Check connection to Flask backend
    fetch('/api/compliance')
      .then(res => {
        if (res.ok) setDbStatus('connected')
        else setDbStatus('error')
      })
      .catch(() => {
        setDbStatus('offline')
      })
  }, [])

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard setActiveTab={setActiveTab} />
      case 'medications':
        return <MedicationManager />
      case 'symptoms':
        return <SymptomTracker />
      case 'vitals':
        return <VitalsTracker />
      case 'chatbot':
        return <AIChatbot />
      case 'report':
        return <ReportGenerator />
      default:
        return <Dashboard setActiveTab={setActiveTab} />
    }
  }

  return (
    <div className="app-container">
      {/* Sidebar Navigation */}
      <aside className="sidebar">
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '40px' }}>
          <div style={{
            background: 'var(--primary-gradient)',
            padding: '8px',
            borderRadius: '10px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 0 15px var(--primary-glow)'
          }}>
            <Heart size={24} color="#0b0f19" />
          </div>
          <div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '1.35rem', fontWeight: 800, letterSpacing: '-0.5px' }}>
              MediAssist<span style={{ color: 'var(--primary)' }}>AI</span>
            </h1>
            <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '1px' }}>
              SDG 3 Companion
            </span>
          </div>
        </div>

        <nav style={{ display: 'flex', flexDirection: 'column', gap: '8px', flex: 1 }}>
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`btn ${activeTab === 'dashboard' ? 'btn-primary' : 'btn-outline'}`}
            style={{ justifyContent: 'flex-start', width: '100%', border: 'none', padding: '12px 16px' }}
          >
            <LayoutDashboard size={18} />
            Dashboard
          </button>

          <button
            onClick={() => setActiveTab('medications')}
            className={`btn ${activeTab === 'medications' ? 'btn-primary' : 'btn-outline'}`}
            style={{ justifyContent: 'flex-start', width: '100%', border: 'none', padding: '12px 16px' }}
          >
            <Pill size={18} />
            Schedule
          </button>

          <button
            onClick={() => setActiveTab('symptoms')}
            className={`btn ${activeTab === 'symptoms' ? 'btn-primary' : 'btn-outline'}`}
            style={{ justifyContent: 'flex-start', width: '100%', border: 'none', padding: '12px 16px' }}
          >
            <Activity size={18} />
            Symptom Diary
          </button>

          <button
            onClick={() => setActiveTab('vitals')}
            className={`btn ${activeTab === 'vitals' ? 'btn-primary' : 'btn-outline'}`}
            style={{ justifyContent: 'flex-start', width: '100%', border: 'none', padding: '12px 16px' }}
          >
            <HeartPulse size={18} />
            Vitals Tracker
          </button>

          <button
            onClick={() => setActiveTab('chatbot')}
            className={`btn ${activeTab === 'chatbot' ? 'btn-primary' : 'btn-outline'}`}
            style={{ justifyContent: 'flex-start', width: '100%', border: 'none', padding: '12px 16px' }}
          >
            <Bot size={18} />
            AI Assistant
          </button>

          <button
            onClick={() => setActiveTab('report')}
            className={`btn ${activeTab === 'report' ? 'btn-primary' : 'btn-outline'}`}
            style={{ justifyContent: 'flex-start', width: '100%', border: 'none', padding: '12px 16px' }}
          >
            <FileText size={18} />
            Project Report
          </button>
        </nav>

        {/* Backend Connectivity Status Indicator */}
        <div className="glass" style={{ padding: '12px', borderRadius: 'var(--radius-sm)', fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div style={{
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            backgroundColor: dbStatus === 'connected' ? '#10b981' : dbStatus === 'connecting' ? '#fbbf24' : '#ef4444'
          }} />
          <span style={{ color: 'var(--text-secondary)' }}>
            {dbStatus === 'connected' ? 'Server Online' : dbStatus === 'connecting' ? 'Connecting...' : 'Server Offline'}
          </span>
        </div>
      </aside>

      {/* Main Content Pane */}
      <main className="main-content">
        {dbStatus === 'offline' && (
          <div className="glass glow-active" style={{ padding: '16px', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '16px', borderLeft: '4px solid var(--accent-red)' }}>
            <ShieldAlert size={24} color="var(--accent-red)" />
            <div>
              <h4 style={{ fontWeight: 600 }}>Backend Server Offline</h4>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                Please run the Flask backend (`python backend/app.py`) to connect the database and activate features.
              </p>
            </div>
          </div>
        )}

        <div className="animate-fade">
          {renderContent()}
        </div>
      </main>
    </div>
  )
}

export default App
