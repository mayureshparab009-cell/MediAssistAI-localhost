import React, { useState, useEffect } from 'react'
import { Activity, Plus, Heart, HeartPulse, Droplets, AlertCircle } from 'lucide-react'

function VitalsTracker() {
  const [vitals, setVitals] = useState([])
  const [showLogForm, setShowLogForm] = useState(false)
  const [loading, setLoading] = useState(true)

  // Form states
  const [systolic, setSystolic] = useState(120)
  const [diastolic, setDiastolic] = useState(80)
  const [bloodSugar, setBloodSugar] = useState(90)
  const [heartRate, setHeartRate] = useState(70)
  const [date, setDate] = useState(new Date().toISOString().split('T')[0])

  const fetchVitals = async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/vitals')
      if (res.ok) {
        const data = await res.json()
        setVitals(data)
      }
    } catch (err) {
      console.error('Error fetching vitals:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchVitals()
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    const newLog = {
      systolic: parseInt(systolic),
      diastolic: parseInt(diastolic),
      blood_sugar: parseInt(bloodSugar),
      heart_rate: parseInt(heartRate),
      date
    }

    try {
      const res = await fetch('/api/vitals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newLog)
      })
      if (res.ok) {
        setSystolic(120)
        setDiastolic(80)
        setBloodSugar(90)
        setHeartRate(70)
        setDate(new Date().toISOString().split('T')[0])
        setShowLogForm(false)
        fetchVitals()
      }
    } catch (err) {
      console.error('Error logging vitals:', err)
    }
  }

  // BP classification helper
  const getBpStatus = (sys, dia) => {
    if (sys < 120 && dia < 80) return { label: 'Normal', color: '#10b981' }
    if (sys < 130 && dia < 80) return { label: 'Elevated', color: '#fbbf24' }
    if (sys < 140 || dia < 90) return { label: 'Hypertension Stage 1', color: '#f87171' }
    return { label: 'Hypertension Stage 2', color: '#ef4444' }
  }

  // Blood sugar classification helper (fasting)
  const getSugarStatus = (val) => {
    if (val < 100) return { label: 'Normal', color: '#10b981' }
    if (val < 126) return { label: 'Prediabetes', color: '#fbbf24' }
    return { label: 'Diabetic Range', color: '#ef4444' }
  }

  // Dynamic Multi-Line SVG Chart for Blood Pressure (Systolic & Diastolic)
  const renderBpChart = () => {
    if (vitals.length < 2) return null

    // Plot last 7 logs chronologically
    const sortedData = [...vitals].reverse().slice(-7)
    const width = 500
    const height = 200
    const padding = 30
    
    const xStep = (width - padding * 2) / (sortedData.length - 1)
    
    // BP ranges from 40 to 180 mmHg
    const minVal = 40
    const maxVal = 180
    const scale = (val) => height - padding - (((val - minVal) / (maxVal - minVal)) * (height - padding * 2))

    const sysPoints = sortedData.map((d, idx) => ({ x: padding + idx * xStep, y: scale(d.systolic), val: d.systolic }))
    const diaPoints = sortedData.map((d, idx) => ({ x: padding + idx * xStep, y: scale(d.diastolic), val: d.diastolic }))

    const sysPath = sysPoints.reduce((acc, p, idx) => idx === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`, '')
    const diaPath = diaPoints.reduce((acc, p, idx) => idx === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`, '')

    return (
      <svg viewBox={`0 0 ${width} ${height}`} style={{ width: '100%', maxHeight: '220px' }}>
        {/* Y-axis grid markers */}
        {[60, 100, 140, 180].map((gridVal) => (
          <g key={gridVal}>
            <line x1={padding} y1={scale(gridVal)} x2={width - padding} y2={scale(gridVal)} stroke="rgba(255,255,255,0.05)" strokeDasharray="3,3" />
            <text x={padding - 5} y={scale(gridVal) + 3} fontSize="8" fill="var(--text-muted)" textAnchor="end">{gridVal}</text>
          </g>
        ))}

        {/* Systolic Line (Coral Red) */}
        <path d={sysPath} fill="none" stroke="#f87171" strokeWidth="3" style={{ filter: 'drop-shadow(0 0 3px rgba(248,113,113,0.2))' }} />
        {/* Diastolic Line (Blue) */}
        <path d={diaPath} fill="none" stroke="#6366f1" strokeWidth="3" style={{ filter: 'drop-shadow(0 0 3px rgba(99,102,241,0.2))' }} />

        {/* Points & Tooltips */}
        {sortedData.map((d, idx) => {
          const sysP = sysPoints[idx]
          const diaP = diaPoints[idx]
          return (
            <g key={idx}>
              {/* Systolic node */}
              <circle cx={sysP.x} cy={sysP.y} r="4" fill="#f87171" stroke="var(--bg-deep)" strokeWidth="1.5" />
              <text x={sysP.x} y={sysP.y - 6} fontSize="8" fill="var(--text-primary)" textAnchor="middle" fontWeight="bold">{d.systolic}</text>

              {/* Diastolic node */}
              <circle cx={diaP.x} cy={diaP.y} r="4" fill="#6366f1" stroke="var(--bg-deep)" strokeWidth="1.5" />
              <text x={diaP.x} y={diaP.y + 11} fontSize="8" fill="var(--text-primary)" textAnchor="middle" fontWeight="bold">{d.diastolic}</text>

              {/* Date label */}
              <text x={sysP.x} y={height - 5} fontSize="8" fill="var(--text-secondary)" textAnchor="middle">{d.date.substring(5)}</text>
            </g>
          )
        })}
      </svg>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {/* Header section */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, marginBottom: '6px' }}>
            Vitals Tracker
          </h2>
          <p style={{ color: 'var(--text-secondary)' }}>
            Monitor key biological markers: Blood Pressure (BP), Fasting Blood Glucose, and Heart Rate trends.
          </p>
        </div>
        
        <button
          onClick={() => setShowLogForm(!showLogForm)}
          className="btn btn-primary"
        >
          <Plus size={18} />
          {showLogForm ? 'Cancel Logger' : 'Log New Vitals'}
        </button>
      </div>

      {/* Logger Form */}
      {showLogForm && (
        <form onSubmit={handleSubmit} className="glass animate-fade" style={{ padding: '28px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
          <div style={{ gridColumn: 'span 2' }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, marginBottom: '8px' }}>
              Record Health Vitals
            </h3>
            <div style={{ height: '1px', background: 'var(--border-light)', marginBottom: '12px' }} />
          </div>

          <div>
            <label htmlFor="sysInput">Systolic Pressure (mmHg)</label>
            <input
              id="sysInput"
              type="number"
              min="60"
              max="220"
              value={systolic}
              onChange={(e) => setSystolic(e.target.value)}
              required
            />
          </div>

          <div>
            <label htmlFor="diaInput">Diastolic Pressure (mmHg)</label>
            <input
              id="diaInput"
              type="number"
              min="40"
              max="130"
              value={diastolic}
              onChange={(e) => setDiastolic(e.target.value)}
              required
            />
          </div>

          <div>
            <label htmlFor="sugarInput">Blood Sugar (mg/dL)</label>
            <input
              id="sugarInput"
              type="number"
              min="40"
              max="400"
              value={bloodSugar}
              onChange={(e) => setBloodSugar(e.target.value)}
              required
            />
          </div>

          <div>
            <label htmlFor="hrInput">Heart Rate (BPM)</label>
            <input
              id="hrInput"
              type="number"
              min="30"
              max="200"
              value={heartRate}
              onChange={(e) => setHeartRate(e.target.value)}
              required
            />
          </div>

          <div style={{ gridColumn: 'span 2' }}>
            <label htmlFor="vDate">Date of Record</label>
            <input
              id="vDate"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
            />
          </div>

          <div style={{ gridColumn: 'span 2', display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '10px' }}>
            <button type="button" onClick={() => setShowLogForm(false)} className="btn btn-outline">
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              Log Vitals
            </button>
          </div>
        </form>
      )}

      {/* Main Grid Layout */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '24px' }}>
        
        {/* Blood Pressure Chart */}
        <div className="glass" style={{ padding: '24px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '8px' }}>
              <HeartPulse size={20} color="#f87171" />
              Blood Pressure Trend (mmHg)
            </h3>
            <div style={{ display: 'flex', gap: '12px', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#f87171' }} /> Systolic
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#6366f1' }} /> Diastolic
              </span>
            </div>
          </div>
          {vitals.length < 2 ? (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '180px', color: 'var(--text-secondary)' }}>
              Log at least 2 entries to visualize blood pressure trends.
            </div>
          ) : renderBpChart()}
        </div>

        {/* History Log Feed */}
        <div className="glass" style={{ padding: '24px' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            📋 Vitals Log Registry
          </h3>

          {loading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: '20px 0' }}>
              <div className="glow-active" style={{ color: 'var(--primary)', fontWeight: 600 }}>Loading registry...</div>
            </div>
          ) : vitals.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '30px 0', color: 'var(--text-secondary)' }}>
              <AlertCircle size={32} style={{ marginBottom: '8px', opacity: 0.5 }} />
              <p>No vitals records logged yet.</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', maxHeight: '260px', overflowY: 'auto', paddingRight: '4px' }}>
              {vitals.map(log => {
                const bpStatus = getBpStatus(log.systolic, log.diastolic)
                const sugarStatus = getSugarStatus(log.blood_sugar)
                return (
                  <div key={log.id} className="glass-interactive" style={{ padding: '14px', borderRadius: 'var(--radius-sm)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                      <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600 }}>📅 {log.date}</span>
                      <span style={{
                        fontSize: '0.7rem',
                        fontWeight: 700,
                        color: bpStatus.color,
                        backgroundColor: `${bpStatus.color}15`,
                        padding: '2px 8px',
                        borderRadius: '4px'
                      }}>
                        BP: {bpStatus.label}
                      </span>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px', fontSize: '0.85rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <Heart size={14} color="#f87171" />
                        <span>BP: <strong>{log.systolic}/{log.diastolic}</strong> <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>mmHg</span></span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <Droplets size={14} color="#00d2c4" />
                        <span>Sugar: <strong>{log.blood_sugar}</strong> <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>mg/dL</span></span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <Activity size={14} color="#6366f1" />
                        <span>Pulse: <strong>{log.heart_rate}</strong> <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>BPM</span></span>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>

      </div>
    </div>
  )
}

export default VitalsTracker
