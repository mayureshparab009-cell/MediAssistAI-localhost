import React, { useState, useRef, useEffect } from 'react'
import { Send, Bot, User, CornerDownLeft, HelpCircle } from 'lucide-react'

// Simple Markdown parser for chatbot responses
function formatResponseText(text) {
  if (!text) return ''
  
  // Replace emergency headers
  let html = text.replace(/⚠️ \*\*CRITICAL EMERGENCY ALERT\*\* ⚠️/g, '<div class="alert-box alert-emergency">⚠️ CRITICAL EMERGENCY ALERT ⚠️</div>')
  
  // Replace warnings
  html = html.replace(/⚠️ \*\*Safety Warning:\*\*/g, '<strong style="color: var(--accent-red)">⚠️ Safety Warning:</strong>')

  // Bold formatting **text**
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
  
  // Bullet items * item
  html = html.split('\n').map(line => {
    if (line.trim().startsWith('* ')) {
      return `<li style="margin-left: 20px; margin-bottom: 4px;">${line.trim().substring(2)}</li>`
    }
    return line
  }).join('\n')

  // Newlines to breaks, except inside block formatting
  html = html.replace(/\n/g, '<br/>')

  return html
}

function AIChatbot() {
  const [messages, setMessages] = useState([
    {
      sender: 'bot',
      text: "👋 Welcome to **MediAssist AI**!\n\nI am your SDG 3 virtual health companion. You can ask me questions about medications (like Aspirin, Metformin, or Lisinopril), general symptoms, or SDG Goal 3.\n\n*Disclaimer: I am an AI, not a clinical doctor. For emergencies, please call emergency services immediately.*",
      suggestions: ["What is SDG 3?", "Metformin side effects", "What if I miss a dose?"]
    }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const chatEndRef = useRef(null)

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, loading])

  const handleSendMessage = async (textToSend) => {
    const text = textToSend || input
    if (!text.trim()) return

    // Add user message
    const userMsg = { sender: 'user', text }
    setMessages(prev => [...prev, userMsg])
    if (!textToSend) setInput('')

    setLoading(true)
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text })
      })

      if (res.ok) {
        const data = await res.json()
        setMessages(prev => [...prev, {
          sender: 'bot',
          text: data.response,
          type: data.type,
          suggestions: data.suggestions
        }])
      } else {
        setMessages(prev => [...prev, {
          sender: 'bot',
          text: "❌ **Error:** Unable to connect to the assistant engine. Please ensure backend is running.",
          type: 'error'
        }])
      }
    } catch (err) {
      console.error('Chatbot fetch error:', err)
      setMessages(prev => [...prev, {
        sender: 'bot',
        text: "🔌 **Network Error:** Could not connect to the backend server. Make sure Flask is running on port 5000.",
        type: 'error'
      }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 120px)', gap: '24px' }}>
      
      {/* Header */}
      <div>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, marginBottom: '6px' }}>
          AI Medical Companion
        </h2>
        <p style={{ color: 'var(--text-secondary)' }}>
          Ask clinical questions, get dosage advice, learn about side effects, or check UN SDG health goals.
        </p>
      </div>

      {/* Chat Pane */}
      <div className="glass" style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', padding: '24px', borderRadius: 'var(--radius-md)' }}>
        
        {/* Messages list */}
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '20px', paddingRight: '8px', marginBottom: '16px' }}>
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className="animate-fade"
              style={{
                display: 'flex',
                gap: '12px',
                alignSelf: msg.sender === 'user' ? 'flex-end' : 'flex-start',
                maxWidth: '80%',
                flexDirection: msg.sender === 'user' ? 'row-reverse' : 'row'
              }}
            >
              {/* Avatar */}
              <div style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
                background: msg.sender === 'user' ? 'var(--secondary-gradient)' : 'var(--primary-gradient)',
                boxShadow: msg.sender === 'user' ? '0 0 10px var(--secondary-glow)' : '0 0 10px var(--primary-glow)'
              }}>
                {msg.sender === 'user' ? <User size={18} color="#fff" /> : <Bot size={18} color="#0b0f19" />}
              </div>

              {/* Text Bubble */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <div
                  className="chat-bubble"
                  style={{
                    padding: '14px 18px',
                    borderRadius: '16px',
                    fontSize: '0.95rem',
                    lineHeight: '1.5',
                    background: msg.sender === 'user' ? 'rgba(99, 102, 241, 0.12)' : 'rgba(255, 255, 255, 0.03)',
                    border: msg.sender === 'user' ? '1px solid rgba(99, 102, 241, 0.2)' : '1px solid var(--border-light)',
                    color: 'var(--text-primary)',
                    boxShadow: 'var(--shadow-sm)',
                    borderTopRightRadius: msg.sender === 'user' ? '4px' : '16px',
                    borderTopLeftRadius: msg.sender === 'user' ? '16px' : '4px',
                    // Apply special styling for emergency
                    borderLeft: msg.type === 'emergency' ? '4px solid var(--accent-red)' : undefined,
                    background: msg.type === 'emergency' ? 'rgba(239, 68, 68, 0.05)' : undefined
                  }}
                  dangerouslySetInnerHTML={{ __html: formatResponseText(msg.text) }}
                />

                {/* Suggestions chips */}
                {msg.sender === 'bot' && msg.suggestions && msg.suggestions.length > 0 && (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '4px' }}>
                    {msg.suggestions.map((sug, sIdx) => (
                      <button
                        key={sIdx}
                        onClick={() => handleSendMessage(sug)}
                        className="btn btn-outline animate-fade"
                        style={{
                          padding: '6px 12px',
                          fontSize: '0.75rem',
                          borderRadius: '20px',
                          borderColor: 'rgba(0, 210, 196, 0.2)',
                          color: 'var(--primary)',
                          background: 'rgba(0, 210, 196, 0.03)'
                        }}
                      >
                        <HelpCircle size={12} />
                        {sug}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}

          {/* Typing Loading Indicator */}
          {loading && (
            <div style={{ display: 'flex', gap: '12px', alignSelf: 'flex-start' }}>
              <div style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                background: 'var(--primary-gradient)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <Bot size={18} color="#0b0f19" className="glow-active" />
              </div>
              <div className="glass" style={{ padding: '12px 18px', borderRadius: '16px', borderTopLeftRadius: '4px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                <span className="glow-active" style={{ fontSize: '0.85rem', color: 'var(--primary)', fontWeight: 600 }}>MediAssist is typing...</span>
              </div>
            </div>
          )}
          
          <div ref={chatEndRef} />
        </div>

        {/* Input area */}
        <div style={{ borderTop: '1px solid var(--border-light)', paddingTop: '16px', display: 'flex', gap: '12px', alignItems: 'center' }}>
          <div style={{ flex: 1, position: 'relative' }}>
            <input
              type="text"
              placeholder="Ask anything about medications, symptoms, or SDG Goal 3..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSendMessage()
              }}
              style={{ paddingRight: '48px' }}
              disabled={loading}
            />
            <div style={{
              position: 'absolute',
              right: '16px',
              top: '50%',
              transform: 'translateY(-50%)',
              fontSize: '0.7rem',
              color: 'var(--text-muted)',
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              pointerEvents: 'none'
            }}>
              <span>Enter</span>
              <CornerDownLeft size={10} />
            </div>
          </div>
          <button
            onClick={() => handleSendMessage()}
            className="btn btn-primary"
            style={{ height: '46px', width: '46px', padding: 0 }}
            disabled={loading || !input.trim()}
          >
            <Send size={18} />
          </button>
        </div>

      </div>

      {/* Embedded Alert Styles */}
      <style>{`
        .alert-box {
          padding: 8px 12px;
          border-radius: 6px;
          margin-bottom: 12px;
          font-weight: bold;
          text-align: center;
        }
        .alert-emergency {
          background-color: rgba(239, 68, 68, 0.15);
          color: #f87171;
          border: 1px solid rgba(239, 68, 68, 0.3);
        }
      `}</style>

    </div>
  )
}

export default AIChatbot
