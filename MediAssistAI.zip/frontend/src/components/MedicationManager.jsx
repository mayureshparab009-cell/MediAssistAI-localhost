import React, { useState, useEffect } from 'react'
import { Plus, Trash2, Clock, Info, AlertTriangle } from 'lucide-react'

function MedicationManager() {
  const [medications, setMedications] = useState([])
  const [showAddForm, setShowAddForm] = useState(false)
  const [loading, setLoading] = useState(true)

  // Form states
  const [name, setName] = useState('')
  const [dosage, setDosage] = useState('')
  const [frequency, setFrequency] = useState('Daily')
  const [time, setTime] = useState('08:00')
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0])
  const [endDate, setEndDate] = useState('')
  const [instructions, setInstructions] = useState('')

  const fetchMedications = async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/medications')
      if (res.ok) {
        const data = await res.json()
        setMedications(data)
      }
    } catch (err) {
      console.error('Error fetching medications:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchMedications()
  }, [])

  // Auto-fill times when frequency changes to improve UX
  useEffect(() => {
    if (frequency === 'Daily') setTime('08:00')
    else if (frequency === 'Twice a day') setTime('08:00, 20:00')
    else if (frequency === 'Three times a day') setTime('08:00, 14:00, 20:00')
  }, [frequency])

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!name || !dosage || !time) return

    const newMed = {
      name,
      dosage,
      frequency,
      time: time.split(',').map(t => t.strip ? t.strip() : t.trim()),
      start_date: startDate,
      end_date: endDate || null,
      instructions
    }

    try {
      const res = await fetch('/api/medications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newMed)
      })
      if (res.ok) {
        // Reset form
        setName('')
        setDosage('')
        setFrequency('Daily')
        setTime('08:00')
        setStartDate(new Date().toISOString().split('T')[0])
        setEndDate('')
        setInstructions('')
        setShowAddForm(false)
        fetchMedications()
      }
    } catch (err) {
      console.error('Error adding medication:', err)
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this medication and all its logs?')) return
    
    try {
      const res = await fetch(`/api/medications/${id}`, {
        method: 'DELETE'
      })
      if (res.ok) {
        fetchMedications()
      }
    } catch (err) {
      console.error('Error deleting medication:', err)
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {/* Header section */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, marginBottom: '6px' }}>
            Medication Scheduler
          </h2>
          <p style={{ color: 'var(--text-secondary)' }}>
            Schedule doses, specify frequencies, and manage patient treatment timelines.
          </p>
        </div>
        
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="btn btn-primary"
        >
          <Plus size={18} />
          {showAddForm ? 'Cancel Scheduler' : 'Add Medication'}
        </button>
      </div>

      {/* Add Medication Form */}
      {showAddForm && (
        <form onSubmit={handleSubmit} className="glass animate-fade" style={{ padding: '28px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
          <div style={{ gridColumn: 'span 2' }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, marginBottom: '8px' }}>
              Schedule New Medication
            </h3>
            <div style={{ height: '1px', background: 'var(--border-light)', marginBottom: '12px' }} />
          </div>

          <div>
            <label htmlFor="medName">Medication Name</label>
            <input
              id="medName"
              type="text"
              placeholder="e.g., Aspirin, Metformin"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div>
            <label htmlFor="dosage">Dosage Strength</label>
            <input
              id="dosage"
              type="text"
              placeholder="e.g., 500mg, 1 tablet"
              value={dosage}
              onChange={(e) => setDosage(e.target.value)}
              required
            />
          </div>

          <div>
            <label htmlFor="frequency">Frequency</label>
            <select
              id="frequency"
              value={frequency}
              onChange={(e) => setFrequency(e.target.value)}
            >
              <option value="Daily">Daily</option>
              <option value="Twice a day">Twice a day</option>
              <option value="Three times a day">Three times a day</option>
            </select>
          </div>

          <div>
            <label htmlFor="time">Scheduled Time(s) (24h format, comma-separated)</label>
            <input
              id="time"
              type="text"
              placeholder="e.g., 08:00, 20:00"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              required
            />
          </div>

          <div>
            <label htmlFor="startDate">Start Date</label>
            <input
              id="startDate"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              required
            />
          </div>

          <div>
            <label htmlFor="endDate">End Date (Optional)</label>
            <input
              id="endDate"
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
            />
          </div>

          <div style={{ gridColumn: 'span 2' }}>
            <label htmlFor="instructions">Special Instructions</label>
            <textarea
              id="instructions"
              placeholder="e.g., Take with food in the morning, do not crush"
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              rows="3"
            />
          </div>

          <div style={{ gridColumn: 'span 2', display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '10px' }}>
            <button type="button" onClick={() => setShowAddForm(false)} className="btn btn-outline">
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              Save Schedule
            </button>
          </div>
        </form>
      )}

      {/* Medication List */}
      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '40px 0' }}>
          <div className="glow-active" style={{ color: 'var(--primary)', fontWeight: 600 }}>Loading Schedule...</div>
        </div>
      ) : medications.length === 0 ? (
        <div className="glass" style={{ padding: '60px', textAlign: 'center', color: 'var(--text-secondary)' }}>
          <AlertTriangle size={40} style={{ marginBottom: '16px', opacity: 0.5, color: 'var(--accent-gold)' }} />
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '8px' }}>
            No Medications Scheduled
          </h3>
          <p style={{ maxWidth: '400px', margin: '0 auto 20px auto', fontSize: '0.9rem' }}>
            Create a medication schedule to track adherence rates and enable smart health assistant features.
          </p>
          <button onClick={() => setShowAddForm(true)} className="btn btn-primary">
            Get Started
          </button>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px' }}>
          {medications.map(med => (
            <div key={med.id} className="glass-interactive" style={{ padding: '24px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
                  <div>
                    <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.35rem', fontWeight: 700 }}>
                      {med.name}
                    </h3>
                    <span style={{ fontSize: '0.85rem', color: 'var(--primary)', fontWeight: 600 }}>
                      Strength: {med.dosage}
                    </span>
                  </div>
                  <button
                    onClick={() => handleDelete(med.id)}
                    className="btn btn-outline"
                    style={{ padding: '8px', color: 'var(--accent-red)', borderColor: 'rgba(248, 113, 113, 0.2)' }}
                    title="Delete Medication"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '20px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Clock size={16} color="var(--primary)" />
                    <span><strong>Times:</strong> {med.time.join(', ')} ({med.frequency})</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Calendar size={16} color="var(--secondary)" />
                    <span><strong>Duration:</strong> {med.start_date} {med.end_date ? `to ${med.end_date}` : '(Ongoing)'}</span>
                  </div>
                  {med.instructions && (
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', background: 'rgba(255,255,255,0.03)', padding: '10px', borderRadius: '6px', marginTop: '6px' }}>
                      <Info size={16} color="var(--accent-gold)" style={{ flexShrink: 0, marginTop: '2px' }} />
                      <span style={{ fontStyle: 'italic' }}>{med.instructions}</span>
                    </div>
                  )}
                </div>
              </div>
              
              <div style={{ display: 'flex', justifyContent: 'flex-end', borderTop: '1px solid var(--border-light)', paddingTop: '16px' }}>
                <span style={{
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  padding: '4px 10px',
                  borderRadius: '20px',
                  backgroundColor: 'rgba(0, 210, 196, 0.1)',
                  color: 'var(--primary)'
                }}>
                  Active Schedule
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default MedicationManager
