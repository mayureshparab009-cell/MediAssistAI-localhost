import React, { useState } from 'react'
import { Download, Copy, Check, FileText, UserCheck } from 'lucide-react'

function ReportGenerator() {
  const [studentName, setStudentName] = useState('John Doe')
  const [rollNumber, setRollNumber] = useState('CS2026001')
  const [collegeName, setCollegeName] = useState('National Institute of Technology')
  const [copied, setCopied] = useState(false)

  const reportContent = `# ACADEMIC PROJECT REPORT: MediAssistAI
--------------------------------------------------
SUBMITTED FOR COLLEGE EXAMINATION / PORTFOLIO
DEVELOPED IN ALIGNMENT WITH UNITED NATIONS SDG 3

DEVELOPER DETAILS:
- Student Name: ${studentName}
- Roll Number: ${rollNumber}
- Institution: ${collegeName}
- Project Title: MediAssistAI - Smart Medication Adherence Assistant
- SDG Target: Goal 3 (Good Health and Well-being)
--------------------------------------------------

1. SELECTED SDG AND REASON FOR SELECTION
-----------------------------------------
Selected Goal: SDG 3 - Good Health and Well-being.
Focus Area: Ensuring healthy lives and promoting well-being for all at all ages.
Importance:
Medication non-adherence is a major silent health crisis. It is estimated that up to 50% of chronic disease medications are not taken as prescribed. This leads to approximately 125,000 deaths annually and accounts for up to 10% of hospitalizations, costing global healthcare systems billions of dollars. Additionally, poor symptom tracking results in delayed diagnoses. MediAssistAI addresses this directly by providing patients with smart medication scheduling, digital symptom diaries, and AI-powered health guidance to support healthy lives.

2. PROBLEM STATEMENT
---------------------
- What is the problem?
  Patient non-adherence to prescribed medication schedules, lack of symptom tracking history, and poor health literacy regarding drug side-effects.
- Where does it exist?
  In domestic healthcare environments, particularly affecting elderly individuals, chronic disease patients (diabetes, hypertension), and post-surgery recovering patients.
- Who is affected?
  Millions of patients globally, clinical doctors (who lack objective patient logs), and family caregivers.
- Why is it serious?
  Skipped doses lead to worsening clinical conditions, emergency hospitalizations, drug resistance, and avoidable mortality.
- What happens if not solved?
  Higher rates of chronic disease complications, higher re-admission costs, and increased pressure on universal healthcare networks.

3. PROPOSED SOLUTION
--------------------
MediAssistAI is an AI-powered health assistant application combining a React frontend, a Flask Python backend, and an SQLite database.
- How it works:
  - Users input their medication schedule (dosage, frequency, and custom timings) via a scheduler interface.
  - The application automatically generates a daily compliance checklist on the home dashboard.
  - Users mark doses as "Taken" or "Missed", and the app computes daily compliance charts.
  - A symptom diary allows users to record daily symptoms (e.g., pain, dizziness) and rate severity from 1 to 10.
  - An intelligent rule-based AI medical chatbot answers queries regarding side-effects, missed doses, and alerts users of emergency clinical symptoms.
- Intended users:
  Chronic disease patients, elderly individuals managing polypharmacy, and caregivers looking to audit medication compliance.

4. PROJECT FEATURES
-------------------
1. Smart Medication Scheduler: Adds prescription timings, start/end dates, and automatically computes daily doses.
2. Compliance Tracker Checklist: Provides interactive checkboxes for today's scheduled medications, tracking compliance rates.
3. Dynamic Adherence Analytics: Uses custom HSL SVG charts to display a 7-day rolling adherence trend to visually assess patient compliance.
4. Symptom Severity Diary: Logs symptoms with a 1-10 severity slider, notes, and visualizes a severity trend plot.
5. AI Health Assistant (Chatbot): Interprets user inquiries about drugs (Aspirin, Metformin, Lisinopril), identifies emergency phrases, and provides clinical advice.
6. Local Data Export: Generates downloadable markdown files for patient records.

5. TECHNOLOGY STACK
-------------------
- Frontend: React.js (Vite), Lucide-React, custom glassmorphic CSS.
- Backend: Flask (Python), Flask-CORS.
- Database: SQLite (SQLAlchemy ORM).
- APIs / Core Engines: Custom Localized Rule-based NLP and Medical Dictionary Engine.

6. PROOF OF WORK & SCREENSHOTS
------------------------------
The system runs locally:
- Frontend Client: http://localhost:5173
- REST API Server: http://localhost:5000
Key Views implemented:
- /dashboard: Core adherence widgets, circular SVG gauge, 7-day progress bars.
- /schedule: Medication list and scheduler configuration panel.
- /symptoms: Pain severity graph and log feed.
- /chatbot: Conversation companion with quick suggestion chips.

7. FUTURE SCOPE
----------------
1. SMS / WhatsApp Reminders: Integration with Twilio API to push SMS alerts to patients.
2. OCR Prescription Scanner: Integrate Tesseract OCR or Vision API to allow patients to upload prescription pictures and automatically populate the scheduler.
3. Family Caregiver Portal: Multi-tenant support enabling children/doctors to monitor patient compliance logs remotely.
4. wearable IoT Integration: Fetch heart rate and activity metrics from smartwatches.

8. CONCLUSION & SDG IMPACT
--------------------------
MediAssistAI directly advances UN SDG 3 by democratizing healthcare accessibility. By tracking medication adherence and encouraging early symptom logging, the system reduces the risk of chronic relapses, empowers patients with health literacy, and decreases emergency hospitalizations.
`

  const handleCopy = () => {
    navigator.clipboard.writeText(reportContent)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleDownload = () => {
    const element = document.createElement("a")
    const file = new Blob([reportContent], { type: 'text/plain' })
    element.href = URL.createObjectURL(file)
    element.download = "PROJECT_REPORT_TEMPLATE.md"
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, marginBottom: '6px' }}>
            Academic Project Report
          </h2>
          <p style={{ color: 'var(--text-secondary)' }}>
            Review, customize, and download your final university project report template aligned with UN SDG 3.
          </p>
        </div>
        
        <div style={{ display: 'flex', gap: '12px' }}>
          <button onClick={handleCopy} className="btn btn-outline">
            {copied ? <Check size={18} color="var(--primary)" /> : <Copy size={18} />}
            {copied ? 'Copied!' : 'Copy Report'}
          </button>
          <button onClick={handleDownload} className="btn btn-primary">
            <Download size={18} />
            Download Report
          </button>
        </div>
      </div>

      {/* Input customization panel */}
      <div className="glass" style={{ padding: '24px' }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 600, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <UserCheck size={18} color="var(--primary)" />
          Customize Submission Credentials
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '16px' }}>
          <div>
            <label htmlFor="studentName">Student Name</label>
            <input
              id="studentName"
              type="text"
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="rollNumber">Roll / Registry ID</label>
            <input
              id="rollNumber"
              type="text"
              value={rollNumber}
              onChange={(e) => setRollNumber(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="collegeName">College / University Name</label>
            <input
              id="collegeName"
              type="text"
              value={collegeName}
              onChange={(e) => setCollegeName(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Report Preview */}
      <div className="glass" style={{ padding: '28px', overflow: 'hidden' }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <FileText size={20} color="var(--primary)" />
          PROJECT_REPORT_TEMPLATE.md Preview
        </h3>
        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '20px' }}>
          This markdown-formatted content compiles all academic guidelines and is ready for submission to your college portal.
        </p>

        <div style={{
          background: 'rgba(11, 15, 25, 0.6)',
          border: '1px solid var(--border-light)',
          borderRadius: '8px',
          padding: '20px',
          maxHeight: '400px',
          overflowY: 'auto',
          fontFamily: 'monospace',
          fontSize: '0.85rem',
          color: 'var(--text-secondary)',
          lineHeight: '1.6',
          whiteSpace: 'pre-wrap'
        }}>
          {reportContent}
        </div>
      </div>

    </div>
  )
}

export default ReportGenerator
