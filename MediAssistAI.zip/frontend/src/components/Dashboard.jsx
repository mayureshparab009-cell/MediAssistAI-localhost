import React, { useState, useEffect } from 'react'
import { Check, X, ClipboardList, TrendingUp, Calendar, AlertCircle, Heart } from 'lucide-react'

function Dashboard({ setActiveTab }) {
  const [stats, setStats] = useState({
    overallCompliance: 100,
    totalTaken: 0,
    totalMissed: 0,
    totalPending: 0,
    dailyTrend: [],
    recentSymptomAverage: 0,
    latestVitals: null
  })
  const [todayLogs, setTodayLogs] = useState([])
  const [loading, setLoading] = useState(true)

  const fetchData = async () => {
    try {
      setLoading(true)
      // Fetch stats
      const statsRes = await fetch('/api/compliance')
      if (statsRes.ok) {
        const statsData = await statsRes.json()
        setStats(statsData)
      }
      
      // Fetch today's schedule checklist
      const logsRes = await fetch('/api/logs/today')
      if (logsRes.ok) {
        const logsData = await logsRes.json()
        setTodayLogs(logsData)
      }
    } catch (err) {
      console.error('Error fetching dashboard data:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [])

  const handleStatusUpdate = async (logId, status) => {
    try {
      const res = await fetch(`/api/logs/${logId}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      })
      if (res.ok) {
        fetchData()
      }
    } catch (err) {
      console.error('Error updating dosage status:', err)
    }
  }

  // Calculate SVG circular progress values
  const radius = 50
  const circumference = 2 * Math.PI * radius
  const strokeDashoffset = circumference - (stats.overallCompliance / 100) * circumference

  if (loading && todayLogs.length === 0) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh' }}>
        <div className="glow-active" style={{ fontSize: '1.2rem', color: 'var(--primary)', fontWeight: 600 }}>Loading Dashboard...</div>
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {/* Header section */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, marginBottom: '6px' }}>
            Good Health Dashboard
          </h2>
          <p style={{ color: 'var(--text-secondary)' }}>
            Real-time compliance tracking & health metrics targeting UN SDG Goal 3.
          </p>
        </div>
        <div className="glass" style={{ padding: '10px 16px', display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.9rem', color: 'var(--primary)', fontWeight: 600 }}>
          <Calendar size={18} />
          {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '24px' }}>
        {/* Compliance Circular Card */}
        <div className="glass" style={{ padding: '24px', display: 'flex', alignItems: 'center', gap: '24px' }}>
          <div style={{ position: 'relative', width: '120px', height: '120px' }}>
            <svg width="120" height="120" style={{ transform: 'rotate(-90deg)' }}>
              <circle cx="60" cy="60" r={radius} fill="transparent" stroke="rgba(255,255,255,0.05)" strokeWidth="10" />
              <circle
                cx="60"
                cy="60"
                r={radius}
                fill="transparent"
                stroke="var(--primary)"
                strokeWidth="10"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                style={{ transition: 'stroke-dashoffset 0.8s ease' }}
              />
            </svg>
            <div style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              textAlign: 'center'
            }}>
              <span style={{ fontSize: '1.5rem', fontWeight: 800, fontFamily: 'var(--font-display)' }}>
                {stats.overallCompliance}%
              </span>
            </div>
          </div>
          <div>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 600, marginBottom: '4px' }}>Adherence Score</h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '8px' }}>
              Your 7-day average medication compliance rate.
            </p>
            <span style={{
              fontSize: '0.75rem',
              fontWeight: 700,
              padding: '2px 8px',
              borderRadius: '4px',
              backgroundColor: stats.overallCompliance >= 85 ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)',
              color: stats.overallCompliance >= 85 ? '#10b981' : '#ef4444'
            }}>
              {stats.overallCompliance >= 85 ? 'Excellent Adherence' : 'Needs Attention'}
            </span>
          </div>
        </div>

        {/* Dose Counters */}
        <div className="glass" style={{ padding: '24px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 600 }}>Dose Tracker</h3>
              <ClipboardList size={20} color="var(--secondary)" />
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Detailed counts of your dosage records over the past week.
            </p>
          </div>
          <div style={{ display: 'flex', gap: '16px', marginTop: '16px' }}>
            <div style={{ flex: 1, textAlign: 'center', background: 'rgba(16, 185, 129, 0.08)', padding: '10px', borderRadius: '8px' }}>
              <div style={{ color: '#10b981', fontSize: '1.5rem', fontWeight: 700 }}>{stats.totalTaken}</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Taken</div>
            </div>
            <div style={{ flex: 1, textAlign: 'center', background: 'rgba(239, 68, 68, 0.08)', padding: '10px', borderRadius: '8px' }}>
              <div style={{ color: '#ef4444', fontSize: '1.5rem', fontWeight: 700 }}>{stats.totalMissed}</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Missed</div>
            </div>
            <div style={{ flex: 1, textAlign: 'center', background: 'rgba(251, 191, 36, 0.08)', padding: '10px', borderRadius: '8px' }}>
              <div style={{ color: '#fbbf24', fontSize: '1.5rem', fontWeight: 700 }}>{stats.totalPending}</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Pending</div>
            </div>
          </div>
        </div>

        {/* Latest Vitals Summary Card */}
        <div className="glass" style={{ padding: '24px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 600 }}>Latest Vitals</h3>
              <Heart size={20} color="#f87171" style={{ animation: 'pulse-glow 1.5s infinite', borderRadius: '50%' }} />
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Last logged vitals indicators.
            </p>
          </div>
          {stats.latestVitals ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', marginTop: '10px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Blood Pressure:</span>
                <strong style={{ color: '#f87171' }}>{stats.latestVitals.systolic}/{stats.latestVitals.diastolic} <span style={{ fontSize: '0.7rem', fontWeight: 500, color: 'var(--text-muted)' }}>mmHg</span></strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Blood Sugar:</span>
                <strong style={{ color: '#00d2c4' }}>{stats.latestVitals.blood_sugar} <span style={{ fontSize: '0.7rem', fontWeight: 500, color: 'var(--text-muted)' }}>mg/dL</span></strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Heart Pulse:</span>
                <strong style={{ color: '#6366f1' }}>{stats.latestVitals.heart_rate} <span style={{ fontSize: '0.7rem', fontWeight: 500, color: 'var(--text-muted)' }}>BPM</span></strong>
              </div>
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '10px 0' }}>
              <button onClick={() => setActiveTab('vitals')} className="btn btn-outline" style={{ padding: '6px 12px', fontSize: '0.8rem' }}>
                Log Vitals
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Grid: Today's Checklist & Trend Chart */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '24px' }}>
        {/* Today's Checklist */}
        <div className="glass animate-fade" style={{ padding: '24px' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            To-do Checklist
          </h3>
          
          {todayLogs.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text-secondary)' }}>
              <AlertCircle size={36} style={{ marginBottom: '12px', opacity: 0.5 }} />
              <p>No medications scheduled for today.</p>
              <button
                className="btn btn-primary"
                style={{ marginTop: '16px', fontSize: '0.85rem' }}
                onClick={() => setActiveTab('medications')}
              >
                Configure Schedule
              </button>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {todayLogs.map(log => (
                <div
                  key={log.id}
                  className="glass-interactive"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '16px',
                    borderRadius: 'var(--radius-sm)',
                    borderLeft: log.status === 'Taken' ? '4px solid #10b981' : log.status === 'Missed' ? '4px solid #ef4444' : '4px solid #fbbf24'
                  }}
                >
                  <div>
                    <h4 style={{ fontWeight: 600 }}>{log.medication_name}</h4>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                      💊 {log.dosage} | ⏰ {log.time}
                    </p>
                  </div>
                  <div style={{ display: 'flex', gap: '8px' }}>
                    {log.status !== 'Taken' && (
                      <button
                        onClick={() => handleStatusUpdate(log.id, 'Taken')}
                        className="btn btn-primary"
                        style={{ padding: '6px 12px', fontSize: '0.8rem' }}
                        title="Mark as Taken"
                      >
                        <Check size={16} /> Taken
                      </button>
                    )}
                    {log.status !== 'Missed' && (
                      <button
                        onClick={() => handleStatusUpdate(log.id, 'Missed')}
                        className="btn btn-danger"
                        style={{ padding: '6px 12px', fontSize: '0.8rem' }}
                        title="Mark as Missed"
                      >
                        <X size={16} /> Missed
                      </button>
                    )}
                    {log.status !== 'Pending' && (
                      <button
                        onClick={() => handleStatusUpdate(log.id, 'Pending')}
                        className="btn btn-outline"
                        style={{ padding: '6px 10px', fontSize: '0.8rem' }}
                        title="Reset status"
                      >
                        Reset
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Dynamic Compliance Chart */}
        <div className="glass" style={{ padding: '24px' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, marginBottom: '16px' }}>
            📊 7-Day Adherence Trend
          </h3>
          
          <div style={{ height: '240px', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', padding: '10px 10px 0 10px' }}>
            {stats.dailyTrend.map((dayData, idx) => {
              const barHeight = `${dayData.compliance * 1.8}px`
              return (
                <div key={idx} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1, gap: '8px' }}>
                  <div style={{ position: 'relative', width: '100%', display: 'flex', justifyContent: 'center' }}>
                    <span style={{ fontSize: '0.7rem', color: 'var(--primary)', fontWeight: 700, marginBottom: '4px', position: 'absolute', bottom: barHeight }}>
                      {dayData.compliance}%
                    </span>
                    <div style={{
                      width: '24px',
                      height: dayData.compliance > 0 ? barHeight : '4px',
                      background: dayData.compliance >= 80 ? 'var(--primary-gradient)' : 'var(--secondary-gradient)',
                      borderRadius: '4px 4px 0 0',
                      boxShadow: dayData.compliance >= 80 ? '0 0 10px var(--primary-glow)' : '0 0 10px var(--secondary-glow)',
                      transition: 'height 1s cubic-bezier(0.4, 0, 0.2, 1)'
                    }} />
                  </div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 500 }}>
                    {dayData.day}
                  </span>
                </div>
              )
            })}
          </div>
          <div style={{ display: 'flex', justifyContent: 'center', gap: '16px', marginTop: '20px', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <div style={{ width: '12px', height: '12px', background: 'var(--primary)', borderRadius: '2px' }} />
              High Adherence (≥80%)
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <div style={{ width: '12px', height: '12px', background: 'var(--secondary)', borderRadius: '2px' }} />
              Lower Adherence (&lt;80%)
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
