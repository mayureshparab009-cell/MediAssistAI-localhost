import React, { useState, useEffect } from 'react'
import { Activity, Plus, HelpCircle, Eye } from 'lucide-react'

function SymptomTracker() {
  const [symptoms, setSymptoms] = useState([])
  const [showLogForm, setShowLogForm] = useState(false)
  const [loading, setLoading] = useState(true)

  // Form states
  const [symptom, setSymptom] = useState('')
  const [severity, setSeverity] = useState(5)
  const [date, setDate] = useState(new Date().toISOString().split('T')[0])
  const [notes, setNotes] = useState('')

  const fetchSymptoms = async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/symptoms')
      if (res.ok) {
        const data = await res.json()
        setSymptoms(data)
      }
    } catch (err) {
      console.error('Error fetching symptoms:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchSymptoms()
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!symptom || !severity) return

    const newLog = {
      symptom,
      severity: parseInt(severity),
      date,
      notes
    }

    try {
      const res = await fetch('/api/symptoms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newLog)
      })
      if (res.ok) {
        setSymptom('')
        setSeverity(5)
        setDate(new Date().toISOString().split('T')[0])
        setNotes('')
        setShowLogForm(false)
        fetchSymptoms()
      }
    } catch (err) {
      console.error('Error logging symptom:', err)
    }
  }

  const getSeverityColor = (score) => {
    if (score <= 3) return '#10b981' // Green
    if (score <= 6) return '#fbbf24' // Gold
    return '#f87171' // Red
  }

  // Generate simple dynamic SVG Line path for severity trend
  const renderTrendChart = () => {
    if (symptoms.length < 2) {
      return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '180px', color: 'var(--text-secondary)' }}>
          <p>Add 2 or more symptom logs to visualize severity trends.</p>
        </div>
      )
    }

    // Chronological order for chart plotting
    const sortedSymptoms = [...symptoms].reverse().slice(-7)
    const width = 500
    const height = 180
    const padding = 25
    
    const xStep = (width - padding * 2) / (sortedSymptoms.length - 1)
    const points = sortedSymptoms.map((sym, idx) => {
      const x = padding + idx * xStep
      // Y-axis inversion (0 severity at bottom, 10 at top)
      const y = height - padding - ((sym.severity / 10) * (height - padding * 2))
      return { x, y, ...sym }
    })

    const pathD = points.reduce((acc, p, idx) => {
      return idx === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`
    }, '')

    return (
      <div style={{ position: 'relative', width: '100%', overflowX: 'auto' }}>
        <svg viewBox={`0 0 ${width} ${height}`} style={{ width: '100%', maxHeight: '200px' }}>
          {/* Grid lines */}
          <line x1={padding} y1={padding} x2={width - padding} y2={padding} stroke="rgba(255,255,255,0.05)" strokeDasharray="3,3" />
          <line x1={padding} y1={height / 2} x2={width - padding} y2={height / 2} stroke="rgba(255,255,255,0.05)" strokeDasharray="3,3" />
          <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="rgba(255,255,255,0.1)" />

          {/* Trend Line */}
          <path d={pathD} fill="none" stroke="var(--primary)" strokeWidth="3" style={{ filter: 'drop-shadow(0 0 4px var(--primary-glow))' }} />

          {/* Node dots */}
          {points.map((p, idx) => (
            <g key={idx}>
              <circle
                cx={p.x}
                cy={p.y}
                r="5"
                fill={getSeverityColor(p.severity)}
                stroke="var(--bg-deep)"
                strokeWidth="2"
              />
              {/* Tooltip text */}
              <text x={p.x} y={p.y - 8} fontSize="9" fill="var(--text-primary)" textAnchor="middle" fontWeight="bold">
                {p.severity}
              </text>
              {/* Date label */}
              <text x={p.x} y={height - 8} fontSize="8" fill="var(--text-secondary)" textAnchor="middle">
                {p.date.substring(5)}
              </text>
            </g>
          ))}
        </svg>
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {/* Header section */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 700, marginBottom: '6px' }}>
            Symptom Diary & Tracker
          </h2>
          <p style={{ color: 'var(--text-secondary)' }}>
            Log physical symptoms, track pain/severity trends, and download logs for clinical reference.
          </p>
        </div>
        
        <button
          onClick={() => setShowLogForm(!showLogForm)}
          className="btn btn-primary"
        >
          <Plus size={18} />
          {showLogForm ? 'Cancel Logger' : 'Log Symptom'}
        </button>
      </div>

      {/* Logger Form */}
      {showLogForm && (
        <form onSubmit={handleSubmit} className="glass animate-fade" style={{ padding: '28px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
          <div style={{ gridColumn: 'span 2' }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, marginBottom: '8px' }}>
              Record Health Status
            </h3>
            <div style={{ height: '1px', background: 'var(--border-light)', marginBottom: '12px' }} />
          </div>

          <div>
            <label htmlFor="symptom">Symptom / Feeling</label>
            <input
              id="symptom"
              type="text"
              placeholder="e.g., Headache, Fatigue, Dizziness"
              value={symptom}
              onChange={(e) => setSymptom(e.target.value)}
              required
            />
          </div>

          <div>
            <label htmlFor="logDate">Date of Occurrence</label>
            <input
              id="logDate"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
            />
          </div>

          <div style={{ gridColumn: 'span 2' }}>
            <label htmlFor="severity" style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Severity Level</span>
              <span style={{ color: getSeverityColor(severity), fontWeight: 700 }}>
                {severity} / 10 ({severity <= 3 ? 'Mild' : severity <= 6 ? 'Moderate' : 'Severe'})
              </span>
            </label>
            <input
              id="severity"
              type="range"
              min="1"
              max="10"
              value={severity}
              onChange={(e) => setSeverity(e.target.value)}
              style={{
                background: `linear-gradient(to right, #10b981 0%, #fbbf24 50%, #f87171 100%)`,
                height: '8px',
                borderRadius: '4px',
                outline: 'none',
                cursor: 'pointer',
                padding: 0
              }}
            />
          </div>

          <div style={{ gridColumn: 'span 2' }}>
            <label htmlFor="notes">Notes / Context</label>
            <textarea
              id="notes"
              placeholder="e.g., Felt it after walking, resolved with hydration, sleep quality was poor..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows="3"
            />
          </div>

          <div style={{ gridColumn: 'span 2', display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '10px' }}>
            <button type="button" onClick={() => setShowLogForm(false)} className="btn btn-outline">
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              Log Record
            </button>
          </div>
        </form>
      )}

      {/* Main Grid: Trend and History */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '24px' }}>
        
        {/* Trend Graph */}
        <div className="glass" style={{ padding: '24px' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Activity size={20} color="var(--primary)" />
            Symptom Severity Trend (Last 7 Logs)
          </h3>
          {renderTrendChart()}
        </div>

        {/* Symptom Log Feed */}
        <div className="glass" style={{ padding: '24px' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            📋 Historical Log Records
          </h3>

          {loading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: '20px 0' }}>
              <div className="glow-active" style={{ color: 'var(--primary)', fontWeight: 600 }}>Loading History...</div>
            </div>
          ) : symptoms.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '30px 0', color: 'var(--text-secondary)' }}>
              <HelpCircle size={32} style={{ marginBottom: '8px', opacity: 0.5 }} />
              <p>No symptoms logged yet. Use the button above to record daily changes.</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', maxHeight: '320px', overflowY: 'auto', paddingRight: '4px' }}>
              {symptoms.map(sym => (
                <div key={sym.id} className="glass-interactive" style={{ padding: '14px', borderRadius: 'var(--radius-sm)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <h4 style={{ fontWeight: 600, fontSize: '0.95rem' }}>{sym.symptom}</h4>
                    <span style={{
                      fontSize: '0.75rem',
                      fontWeight: 700,
                      color: getSeverityColor(sym.severity),
                      backgroundColor: `${getSeverityColor(sym.severity)}15`,
                      padding: '2px 8px',
                      borderRadius: '4px'
                    }}>
                      Sev: {sym.severity}
                    </span>
                  </div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                    📅 {sym.date}
                  </div>
                  {sym.notes && (
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '8px', background: 'rgba(255,255,255,0.02)', padding: '8px', borderRadius: '4px', fontStyle: 'italic' }}>
                      {sym.notes}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  )
}

export default SymptomTracker
