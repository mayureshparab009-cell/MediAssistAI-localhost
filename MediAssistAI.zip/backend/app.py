from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime, timedelta
import os

from models import db, Medication, MedicationLog, SymptomLog, VitalsLog
from database import init_db
from chatbot import get_bot_response

app = Flask(__name__)
CORS(app)

# SQLite database path
db_path = os.path.join(os.path.dirname(__file__), 'mediassist.db')
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize DB
init_db(app)

# Helper to get today's date string
def get_today_str():
    return datetime.now().strftime('%Y-%m-%d')

@app.route('/api/medications', methods=['GET'])
def get_medications():
    medications = Medication.query.filter_by(active=True).all()
    return jsonify([med.to_dict() for med in medications])

@app.route('/api/medications', methods=['POST'])
def add_medication():
    data = request.json
    if not data or not data.get('name') or not data.get('dosage') or not data.get('frequency') or not data.get('time'):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Check if time is a list or string
    times = data.get('time')
    if isinstance(times, list):
        time_str = ','.join(times)
    else:
        time_str = times

    med = Medication(
        name=data['name'],
        dosage=data['dosage'],
        frequency=data['frequency'],
        time=time_str,
        start_date=data.get('start_date', get_today_str()),
        end_date=data.get('end_date'),
        instructions=data.get('instructions', ''),
        active=True
    )
    db.session.add(med)
    db.session.commit()
    
    # Auto-initialize logs for today for this new medication if active
    today_str = get_today_str()
    for t in time_str.split(','):
        # check if it already exists
        existing = MedicationLog.query.filter_by(medication_id=med.id, date=today_str, time=t.strip()).first()
        if not existing:
            log = MedicationLog(
                medication_id=med.id,
                date=today_str,
                time=t.strip(),
                status='Pending'
            )
            db.session.add(log)
    db.session.commit()

    return jsonify(med.to_dict()), 201

@app.route('/api/medications/<int:med_id>', methods=['DELETE'])
def delete_medication(med_id):
    med = Medication.query.get_or_404(med_id)
    # Hard delete medication and cascades logs
    db.session.delete(med)
    db.session.commit()
    return jsonify({'message': 'Medication deleted successfully'})

@app.route('/api/logs/today', methods=['GET'])
def get_today_logs():
    today_str = get_today_str()
    active_meds = Medication.query.filter_by(active=True).all()
    
    # Ensure logs exist for all active medications scheduled for today
    for med in active_meds:
        # Check if today lies within medication validity
        med_start = datetime.strptime(med.start_date, '%Y-%m-%d')
        med_end = datetime.strptime(med.end_date, '%Y-%m-%d') if med.end_date else None
        today_dt = datetime.strptime(today_str, '%Y-%m-%d')
        
        if med_start <= today_dt and (not med_end or today_dt <= med_end):
            # Split time configurations
            times = med.time.split(',')
            for t in times:
                t = t.strip()
                # Check if a log exists for today at this time
                log = MedicationLog.query.filter_by(medication_id=med.id, date=today_str, time=t).first()
                if not log:
                    # Create a new pending log
                    new_log = MedicationLog(
                        medication_id=med.id,
                        date=today_str,
                        time=t,
                        status='Pending'
                    )
                    db.session.add(new_log)
    db.session.commit()
    
    # Retrieve all logs for today
    today_logs = MedicationLog.query.filter_by(date=today_str).all()
    return jsonify([log.to_dict() for log in today_logs])

@app.route('/api/logs/<int:log_id>/status', methods=['POST'])
def update_log_status(log_id):
    data = request.json
    new_status = data.get('status')
    if new_status not in ['Taken', 'Missed', 'Pending']:
        return jsonify({'error': 'Invalid status'}), 400
        
    log = MedicationLog.query.get_or_404(log_id)
    log.status = new_status
    if new_status == 'Taken':
        log.logged_at = datetime.utcnow()
    else:
        log.logged_at = None
    db.session.commit()
    return jsonify(log.to_dict())

@app.route('/api/symptoms', methods=['GET'])
def get_symptoms():
    symptoms = SymptomLog.query.order_by(SymptomLog.date.desc()).all()
    return jsonify([sym.to_dict() for sym in symptoms])

@app.route('/api/symptoms', methods=['POST'])
def add_symptom():
    data = request.json
    if not data or not data.get('symptom') or not data.get('severity'):
        return jsonify({'error': 'Missing required fields'}), 400
        
    sym = SymptomLog(
        date=data.get('date', get_today_str()),
        symptom=data['symptom'],
        severity=int(data['severity']),
        notes=data.get('notes', '')
    )
    db.session.add(sym)
    db.session.commit()
    return jsonify(sym.to_dict()), 201

@app.route('/api/vitals', methods=['GET'])
def get_vitals():
    logs = VitalsLog.query.order_by(VitalsLog.date.desc()).all()
    return jsonify([log.to_dict() for log in logs])

@app.route('/api/vitals', methods=['POST'])
def add_vitals():
    data = request.json
    if not data or not data.get('systolic') or not data.get('diastolic') or not data.get('blood_sugar') or not data.get('heart_rate'):
        return jsonify({'error': 'Missing required fields'}), 400
        
    v_log = VitalsLog(
        date=data.get('date', get_today_str()),
        systolic=int(data['systolic']),
        diastolic=int(data['diastolic']),
        blood_sugar=int(data['blood_sugar']),
        heart_rate=int(data['heart_rate'])
    )
    db.session.add(v_log)
    db.session.commit()
    return jsonify(v_log.to_dict()), 201

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json
    message = data.get('message', '')
    if not message:
        return jsonify({'error': 'Empty message'}), 400
        
    response_data = get_bot_response(message)
    return jsonify(response_data)

@app.route('/api/compliance', methods=['GET'])
def get_compliance_stats():
    # Adherence over last 7 days
    today = datetime.now()
    days_data = []
    total_taken = 0
    total_missed = 0
    total_pending = 0
    
    for i in range(6, -1, -1):
        date_str = (today - timedelta(days=i)).strftime('%Y-%m-%d')
        logs = MedicationLog.query.filter_by(date=date_str).all()
        
        taken = sum(1 for l in logs if l.status == 'Taken')
        missed = sum(1 for l in logs if l.status == 'Missed')
        pending = sum(1 for l in logs if l.status == 'Pending')
        
        total_taken += taken
        total_missed += missed
        total_pending += pending
        
        total_daily_doses = taken + missed
        compliance = 100.0 if total_daily_doses == 0 else (taken / total_daily_doses) * 100
        
        days_data.append({
            'date': date_str,
            'day': (today - timedelta(days=i)).strftime('%a'),
            'taken': taken,
            'missed': missed,
            'pending': pending,
            'compliance': round(compliance, 1)
        })
        
    overall_compliance = 100.0
    if (total_taken + total_missed) > 0:
        overall_compliance = (total_taken / (total_taken + total_missed)) * 100
        
    # Symptom stats
    symptoms = SymptomLog.query.order_by(SymptomLog.date.desc()).limit(10).all()
    avg_severity = 0
    if symptoms:
        avg_severity = sum(s.severity for s in symptoms) / len(symptoms)
        
    # Latest Vitals
    latest_vitals = VitalsLog.query.order_by(VitalsLog.date.desc()).first()
    vitals_dict = None
    if latest_vitals:
        vitals_dict = latest_vitals.to_dict()
        
    return jsonify({
        'overallCompliance': round(overall_compliance, 1),
        'totalTaken': total_taken,
        'totalMissed': total_missed,
        'totalPending': total_pending,
        'dailyTrend': days_data,
        'recentSymptomAverage': round(avg_severity, 1),
        'latestVitals': vitals_dict
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
