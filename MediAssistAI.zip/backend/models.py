from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Medication(db.Model):
    __tablename__ = 'medications'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    dosage = db.Column(db.String(50), nullable=False)  # e.g., "500mg", "1 tablet"
    frequency = db.Column(db.String(50), nullable=False)  # e.g., "Daily", "Twice a day"
    time = db.Column(db.String(100), nullable=False)  # comma separated hours, e.g., "08:00,20:00"
    start_date = db.Column(db.String(10), nullable=False)  # YYYY-MM-DD
    end_date = db.Column(db.String(10), nullable=True)  # YYYY-MM-DD
    instructions = db.Column(db.String(250), nullable=True)  # e.g., "Take with meals"
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationship to logs
    logs = db.relationship('MedicationLog', backref='medication', lazy=True, cascade="all, delete-orphan")

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'dosage': self.dosage,
            'frequency': self.frequency,
            'time': self.time.split(','),
            'start_date': self.start_date,
            'end_date': self.end_date,
            'instructions': self.instructions,
            'active': self.active
        }

class MedicationLog(db.Model):
    __tablename__ = 'medication_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    medication_id = db.Column(db.Integer, db.ForeignKey('medications.id'), nullable=False)
    date = db.Column(db.String(10), nullable=False)  # YYYY-MM-DD
    time = db.Column(db.String(5), nullable=False)  # HH:MM scheduled time
    status = db.Column(db.String(20), default='Pending')  # 'Taken', 'Missed', 'Pending'
    logged_at = db.Column(db.DateTime, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'medication_id': self.medication_id,
            'medication_name': self.medication.name if self.medication else 'Unknown',
            'dosage': self.medication.dosage if self.medication else '',
            'date': self.date,
            'time': self.time,
            'status': self.status,
            'logged_at': self.logged_at.isoformat() if self.logged_at else None
        }

class SymptomLog(db.Model):
    __tablename__ = 'symptom_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.String(10), nullable=False)  # YYYY-MM-DD
    symptom = db.Column(db.String(100), nullable=False)  # e.g., "Headache", "Nausea"
    severity = db.Column(db.Integer, nullable=False)  # 1 to 10
    notes = db.Column(db.Text, nullable=True)
    logged_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'date': self.date,
            'symptom': self.symptom,
            'severity': self.severity,
            'notes': self.notes,
            'logged_at': self.logged_at.isoformat()
        }

class VitalsLog(db.Model):
    __tablename__ = 'vitals_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.String(10), nullable=False)  # YYYY-MM-DD
    systolic = db.Column(db.Integer, nullable=False)  # mmHg (e.g., 120)
    diastolic = db.Column(db.Integer, nullable=False)  # mmHg (e.g., 80)
    blood_sugar = db.Column(db.Integer, nullable=False)  # mg/dL (e.g., 95)
    heart_rate = db.Column(db.Integer, nullable=False)  # BPM (e.g., 72)
    logged_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'date': self.date,
            'systolic': self.systolic,
            'diastolic': self.diastolic,
            'blood_sugar': self.blood_sugar,
            'heart_rate': self.heart_rate,
            'logged_at': self.logged_at.isoformat()
        }
