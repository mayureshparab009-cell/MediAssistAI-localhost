from models import db, Medication, MedicationLog, SymptomLog, VitalsLog
from datetime import datetime, timedelta

def init_db(app):
    db.init_app(app)
    with app.app_context():
        db.create_all()
        seed_data()

def seed_data():
    # Check if we already have data
    if Medication.query.first() is not None:
        return

    # Seed Medications
    med1 = Medication(
        name="Aspirin",
        dosage="81mg",
        frequency="Daily",
        time="08:00",
        start_date=(datetime.now() - timedelta(days=10)).strftime('%Y-%m-%d'),
        instructions="Take with food in the morning",
        active=True
    )
    
    med2 = Medication(
        name="Metformin",
        dosage="500mg",
        frequency="Twice a day",
        time="08:00,20:00",
        start_date=(datetime.now() - timedelta(days=10)).strftime('%Y-%m-%d'),
        instructions="Take with breakfast and dinner",
        active=True
    )
    
    med3 = Medication(
        name="Lisinopril",
        dosage="10mg",
        frequency="Daily",
        time="20:00",
        start_date=(datetime.now() - timedelta(days=5)).strftime('%Y-%m-%d'),
        instructions="Take at bedtime",
        active=True
    )
    
    db.session.add(med1)
    db.session.add(med2)
    db.session.add(med3)
    db.session.commit()

    # Seed logs for the past 7 days
    today = datetime.now()
    for i in range(7):
        date_str = (today - timedelta(days=i)).strftime('%Y-%m-%d')
        
        # Aspirin log
        status1 = "Taken" if i != 2 else "Missed"  # mock a missed dose 2 days ago
        log1 = MedicationLog(
            medication_id=med1.id,
            date=date_str,
            time="08:00",
            status=status1,
            logged_at=datetime.strptime(f"{date_str} 08:15:00", "%Y-%m-%d %H:%M:%S") if status1 == "Taken" else None
        )
        
        # Metformin logs
        status2_1 = "Taken"
        log2_1 = MedicationLog(
            medication_id=med2.id,
            date=date_str,
            time="08:00",
            status=status2_1,
            logged_at=datetime.strptime(f"{date_str} 08:30:00", "%Y-%m-%d %H:%M:%S")
        )
        status2_2 = "Taken" if i != 4 else "Missed"
        log2_2 = MedicationLog(
            medication_id=med2.id,
            date=date_str,
            time="20:00",
            status=status2_2,
            logged_at=datetime.strptime(f"{date_str} 20:05:00", "%Y-%m-%d %H:%M:%S") if status2_2 == "Taken" else None
        )
        
        # Lisinopril log (started 5 days ago)
        if i <= 5:
            status3 = "Taken"
            log3 = MedicationLog(
                medication_id=med3.id,
                date=date_str,
                time="20:00",
                status=status3,
                logged_at=datetime.strptime(f"{date_str} 20:10:00", "%Y-%m-%d %H:%M:%S")
            )
            db.session.add(log3)

        db.session.add(log1)
        db.session.add(log2_1)
        db.session.add(log2_2)

    # Seed Symptom logs
    sym1 = SymptomLog(
        date=(today - timedelta(days=4)).strftime('%Y-%m-%d'),
        symptom="Mild Headache",
        severity=3,
        notes="Felt in the afternoon, resolved after resting."
    )
    sym2 = SymptomLog(
        date=(today - timedelta(days=2)).strftime('%Y-%m-%d'),
        symptom="Fatigue",
        severity=4,
        notes="Felt sluggish after lunch."
    )
    sym3 = SymptomLog(
        date=(today - timedelta(days=1)).strftime('%Y-%m-%d'),
        symptom="Dizziness",
        severity=2,
        notes="Brief lightheadedness when standing up quickly."
    )
    
    db.session.add(sym1)
    db.session.add(sym2)
    db.session.add(sym3)

    # Seed Vitals logs for the last 5 days
    vitals_data = [
        {"days_ago": 4, "sys": 118, "dia": 79, "sugar": 92, "hr": 68},
        {"days_ago": 3, "sys": 122, "dia": 81, "sugar": 98, "hr": 70},
        {"days_ago": 2, "sys": 120, "dia": 80, "sugar": 95, "hr": 72},
        {"days_ago": 1, "sys": 124, "dia": 83, "sugar": 105, "hr": 75},
        {"days_ago": 0, "sys": 119, "dia": 78, "sugar": 90, "hr": 69}
    ]
    
    for v in vitals_data:
        v_log = VitalsLog(
            date=(today - timedelta(days=v["days_ago"])).strftime('%Y-%m-%d'),
            systolic=v["sys"],
            diastolic=v["dia"],
            blood_sugar=v["sugar"],
            heart_rate=v["hr"]
        )
        db.session.add(v_log)

    db.session.commit()
    print("Database seeded successfully with medications, symptoms, and vitals!")
