import re
import random

def get_bot_response(message):
    msg = message.lower().strip()
    
    # Emergency check first
    emergency_keywords = [
        "chest pain", "pressure in chest", "heart attack", "difficulty breathing", 
        "shortness of breath", "severe bleeding", "stroke", "paralysis", "face drooping"
    ]
    if any(keyword in msg for keyword in emergency_keywords):
        return {
            "response": (
                "⚠️ **CRITICAL EMERGENCY ALERT** ⚠️\n\n"
                "The symptoms you described (chest pain, shortness of breath, or potential stroke signs) "
                "can be life-threatening. **Please immediately call emergency services (e.g., 911 or your local emergency number) "
                "or go to the nearest emergency room.**\n\n"
                "Do not wait to see if symptoms improve. Avoid driving yourself if possible; wait for paramedics."
            ),
            "type": "emergency",
            "suggestions": ["Emergency Contacts", "First Aid Tips", "Return to Chat"]
        }

    # Greetings
    if re.search(r'\b(hello|hi|hey|greetings|good morning|good afternoon|good evening)\b', msg):
        return {
            "response": (
                "👋 Hello! I am **MediAssist AI**, your virtual health companion.\n\n"
                "I can assist you with:\n"
                "* 💊 **Medication guidelines** (e.g., side effects, instructions)\n"
                "* 📊 **Symptom analysis** (providing educational insights)\n"
                "* 📅 **Reminders & adherence tips**\n"
                "* 🥗 **General wellness guidance** (SDG 3 - Good Health & Well-being)\n\n"
                "How can I help you today? Please remember I am an AI, not a doctor. For serious issues, always consult a medical professional."
            ),
            "type": "general",
            "suggestions": ["Medication Side Effects", "Track Today's Doses", "Healthy Lifestyle Tips"]
        }

    # Missed dosage query
    if "miss" in msg and ("dose" in msg or "med" in msg or "pill" in msg or "tablet" in msg):
        return {
            "response": (
                "❓ **What to do if you miss a medication dose:**\n\n"
                "1. **Check the Package Insert:** Different medications have specific rules.\n"
                "2. **Rule of Thumb:** If you remember close to the scheduled time, take it immediately. "
                "However, if it is almost time for your next scheduled dose, **skip the missed dose** and resume your regular schedule.\n"
                "3. **⚠️ NEVER DOUBLE THE DOSE** to catch up, as this can lead to toxicity or severe side effects.\n\n"
                "If you are unsure, feel free to mention the specific drug name, or contact your pharmacist."
            ),
            "type": "guidance",
            "suggestions": ["Aspirin missed dose", "Metformin missed dose", "View My Schedule"]
        }

    # Lisinopril
    if "lisinopril" in msg:
        return {
            "response": (
                "💊 **Lisinopril (ACE Inhibitor):**\n\n"
                "* **Common Uses:** Treatment of High Blood Pressure (Hypertension) and Heart Failure. Helps protect kidneys in diabetic patients.\n"
                "* **Standard Timing:** Usually taken once daily, with or without food. Bedtime is often recommended for the first dose to prevent dizziness.\n"
                "* **Common Side Effects:** Persistent dry cough, dizziness, headache, fatigue.\n"
                "* **⚠️ Safety Warning:** Avoid potassium supplements or salt substitutes unless advised by a doctor. Seek immediate care if you experience swelling of the face, lips, or tongue (angioedema)."
            ),
            "type": "medication",
            "suggestions": ["Lisinopril side effects", "What is ACE Inhibitor?", "My Blood Pressure Log"]
        }

    # Metformin
    if "metformin" in msg:
        return {
            "response": (
                "💊 **Metformin (Biguanide Antidiabetic):**\n\n"
                "* **Common Uses:** Management of Type 2 Diabetes to lower blood glucose levels.\n"
                "* **Standard Timing:** Taken with meals (breakfast/dinner) to minimize stomach upset.\n"
                "* **Common Side Effects:** Nausea, diarrhea, abdominal pain, metallic taste, loss of appetite.\n"
                "* **⚠️ Safety Warning:** Limit alcohol consumption. Report symptoms of extreme fatigue, muscle pain, or difficulty breathing, which could indicate a rare but serious condition called *lactic acidosis*."
            ),
            "type": "medication",
            "suggestions": ["Metformin side effects", "Type 2 Diabetes diet", "Medication schedule"]
        }

    # Aspirin
    if "aspirin" in msg:
        return {
            "response": (
                "💊 **Aspirin (NSAID / Antiplatelet):**\n\n"
                "* **Common Uses:** Pain relief, fever reduction, reducing inflammation. Low-dose (81mg) is widely prescribed to prevent blood clots, heart attacks, and strokes.\n"
                "* **Standard Timing:** Take with food or a full glass of water to protect your stomach lining.\n"
                "* **Common Side Effects:** Indigestion, mild nausea, increased bruising/bleeding tendencies.\n"
                "* **⚠️ Safety Warning:** Do not take other NSAIDs (like Ibuprofen/Naproxen) concurrently without consulting your doctor. Watch for signs of dark, tarry stools or vomiting blood, which indicate gastrointestinal bleeding."
            ),
            "type": "medication",
            "suggestions": ["Aspirin side effects", "Antiplatelet therapy", "Symptom diary"]
        }

    # Headache
    if "headache" in msg:
        return {
            "response": (
                "🤕 **Educational Insights on Headaches:**\n\n"
                "* **Common Types:** Tension headaches (stress-related), Migraines (throbbing, sensitive to light/sound), or Sinus headaches (pressure in forehead/cheeks).\n"
                "* **Home Care Tips:**\n"
                "  1. Stay hydrated (drink plenty of water).\n"
                "  2. Rest in a quiet, dark room.\n"
                "  3. Apply a cold compress to your forehead or temples.\n"
                "  4. Practice relaxation techniques.\n"
                "* **When to see a Doctor:** If the headache is sudden and extremely severe ('thunderclap' headache), accompanied by fever, stiff neck, confusion, numbness, or vision changes."
            ),
            "type": "symptom",
            "suggestions": ["Migraine triggers", "Hydration tips", "Log a Symptom"]
        }

    # Fatigue
    if "fatigue" in msg or "tired" in msg or "sluggish" in msg or "weak" in msg:
        return {
            "response": (
                "🥱 **Understanding Fatigue:**\n\n"
                "Persistent tiredness can stem from various physical and lifestyle factors:\n"
                "* **Lifestyle Factors:** Lack of sleep, poor nutrition, dehydration, sedentary lifestyle, or excessive caffeine/alcohol.\n"
                "* **Medical Conditions:** Anemia, thyroid disorders (hypothyroidism), diabetes, or vitamin deficiencies (Vitamin D, B12).\n"
                "* **Action Plan:**\n"
                "  1. Aim for 7-9 hours of consistent sleep.\n"
                "  2. Eat a balanced diet rich in whole grains, proteins, and vegetables.\n"
                "  3. Engage in regular light exercise (like walking).\n"
                "  4. Limit screen time before bed."
            ),
            "type": "symptom",
            "suggestions": ["Sleep hygiene tips", "Vitamin deficiencies", "Log fatigue level"]
        }

    # SDG 3 & Wellness
    if "sdg" in msg or "sustainable development goal" in msg or "good health" in msg:
        return {
            "response": (
                "🎯 **United Nations SDG 3: Good Health and Well-being**\n\n"
                "SDG 3 aims to ensure healthy lives and promote well-being for all at all ages.\n\n"
                "**Key Goals include:**\n"
                "* Reducing maternal and neonatal mortality.\n"
                "* Ending epidemics of communicable diseases (AIDS, Malaria, TB).\n"
                "* Strengthening prevention and treatment of substance abuse.\n"
                "* **Halving global deaths and injuries from road traffic accidents.**\n"
                "* **Achieving Universal Health Coverage (UHC)** and access to safe, affordable medicines/vaccines.\n\n"
                "MediAssistAI supports SDG 3 by helping patients manage medication schedules, track symptoms early, and gain medical literacy."
            ),
            "type": "general",
            "suggestions": ["UN SDG 3 Official Site", "How MediAssistAI helps", "General wellness tips"]
        }

    # General fallback
    responses = [
        "I understand you are asking about that. While I don't have a specific medical profile for it, I suggest reviewing it with your care provider. Remember to maintain a balanced lifestyle (hydration, sleep, nutrition) for good health!",
        "That is an interesting health query. In the context of SDG 3 (Good Health & Well-being), self-education is important. However, for specialized advice, always consult your physician or pharmacist.",
        "As your virtual health companion, I recommend tracking symptoms like that in our **Symptom Tracker** tab. It creates a visual history that you can export and share with your doctor during your next visit.",
        "To provide accurate medication guidelines, please check the spelling or specify if it is Aspirin, Metformin, or Lisinopril, which are currently configured in your schedule."
    ]
    
    return {
        "response": (
            "🤖 **MediAssist AI response:**\n\n"
            f"{random.choice(responses)}\n\n"
            "*Disclaimer: This response is for informational purposes only. Do not use it as a substitute for professional medical advice, diagnosis, or treatment.*"
        ),
        "type": "general",
        "suggestions": ["Tell me about Aspirin", "What is SDG 3?", "Symptom Logging"]
    }
